/* eslint-disable */
import React from 'react';
import '../../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Content } from '@components/styled-components/Task';

export default class DeleteReportAndHistory extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    deleteAll(event){
        console.log(`Delete all files here: ${event.target.value}`);
        // TO DO - Implement necessary logic to delete report and history here.
    };

    render() {
        return (
            <div className="popup" border="primary">
                <div className="popup_inner">
                    <Content>
                        <h5>Are you sure you want to delete this report and its history?</h5>
                        <strong>
                            If you delete the
                            <b>executive metrics</b>
                            {' '}
                            report, you will also delete the associated history.
                        </strong>
                    </Content>
                    <br />
                    <br />
                    <div className="ex3">
                        January 2020
                        <br />
                        February 2020
                        <br />
                        May 2020
                        <br />
                        June 2020
                        <br />
                        July 2020
                        <br />
                        August 2020
                        <br />
                        September 2020
                        <br />
                        October 2020
                        <br />
                        November 2020
                        <br />
                        December 2020
                        <br />
                    </div>
                    <Content>
                    <br />
                    <br />
                    <strong>
                        Please type the word 'Delete' to remove the
                        <b>executive metrics</b>
                        {' '}
                        report and its associated history.
                    </strong>
                    <br />
                    <input type="text" name="deleteVar" placeholder="Delete" />
                    </Content>
                    <br />
                    <br />
                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <button type="button" variant="secondary" onClick={this.props.closePopup}>Close</button>
                        {' '}
                        <button type="button" className="btn-outline-primary" color="primary" onClick={this.deleteAll} value={this.props.text}>Delete All</button>
                        {' '}
                        <button type="button" className="btn-outline-primary" color="primary" onClick={this.props.closePopup}>Cancel</button>
                    </div>
                </div>
            </div>
        );
    }
}
