/* eslint-disable */
import React from 'react';
import '../../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import DeleteFiles from './DeleteFiles';
import DeleteReportAndHistory from './DeleteReportAndHistory';
import Spinner from './Spinner';

export default class Modals extends React.Component {
  constructor() {
    super();
    this.state = {
      showPopupLoading: false,
      showPopupDeleteFiles: false,
      showPopupDeleteReportAndHistory: false
    };
  }

  togglePopupLoading() {
    this.setState({
      showPopupLoading: !this.state.showPopupLoading
    });
  }

  togglePopupDeleteFiles() {
    this.setState({
      showPopupDeleteFiles: !this.state.showPopupDeleteFiles
    });
  }

  togglePopupDeleteReportAndHistory() {
    this.setState({
      showPopupDeleteReportAndHistory: !this.state.showPopupDeleteReportAndHistory
    });
  }

  render() {
    return (
      <div className="app">
        <br />
        <br />
        <button type="button" variant="primary" className="btn-primary" onClick={this.togglePopupLoading.bind(this)}>Data loading modal</button>
        <br />
        <br />
        <button type="button" variant="primary" className="btn btn-warning" onClick={this.togglePopupDeleteFiles.bind(this)}>Delete files modal</button>
        <br />
        <br />
        <button type="button" variant="primary" className="btn btn-warning" onClick={this.togglePopupDeleteReportAndHistory.bind(this)}>Delete report and history modal</button>

        {this.state.showPopupLoading
          ? (
            <Spinner
              closePopup={this.togglePopupLoading.bind(this)}
            />
          )
          : null}

        {this.state.showPopupDeleteFiles
          ? (
            <DeleteFiles
              text="Pass Details of the file to be deleted here."
              closePopup={this.togglePopupDeleteFiles.bind(this)}
            />
          )
          : null}

        {this.state.showPopupDeleteReportAndHistory
          ? (
            <DeleteReportAndHistory
              text="Pass Details of records to be deleted here."
              closePopup={this.togglePopupDeleteReportAndHistory.bind(this)}
            />
          )
          : null}
      </div>
    );
  }
}

