import React from 'react';
import { render } from '@testing-library/react';
import DeleteReportAndHistory from '../DeleteReportAndHistory.jsx';
import 'jest-styled-components';

it('renders correctly', () => {
  const { container } = render(<DeleteReportAndHistory />);
  expect(container).toMatchSnapshot();
});
