import React from 'react';
import { render } from '@testing-library/react';
import DeleteFiles from '../DeleteFiles.jsx';
import 'jest-styled-components';

it('renders correctly', () => {
  const { container } = render(<DeleteFiles />);
  expect(container).toMatchSnapshot();
});
