import React from 'react';
import { render } from '@testing-library/react';
import Spinner from '../Spinner.jsx';
import 'jest-styled-components';

it('renders correctly', () => {
  const { container } = render(<Spinner />);
  expect(container).toMatchSnapshot();
});
