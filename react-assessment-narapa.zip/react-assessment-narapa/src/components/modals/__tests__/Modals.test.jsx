import React from 'react';
import { render } from '@testing-library/react';
import Modals from '../Modals.jsx';
import 'jest-styled-components';

it('renders correctly', () => {
  const { container } = render(<Modals />);
  expect(container).toMatchSnapshot();
});
