/* eslint-disable */
import React from 'react';
import '../../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Spinner extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="popup">
        <div className="popup_inner">
          <div className="spinner-box">
            <div className="loading-icon" />
            <span>Data is Loading...</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="button" variant="secondary" className="btn-outline-primary" onClick={this.props.closePopup}>Close</button>
          </div>
        </div>
      </div>
    );
  }
}
