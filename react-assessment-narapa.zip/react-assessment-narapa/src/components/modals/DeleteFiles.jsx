/* eslint-disable */
import React from 'react';
import '../../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Content } from '@components/styled-components/Task';

const deleteFile = (event) => {
  console.log(`Deleting file name...${event.target.value}`);
  // TO DO - Implement necessary logic to delete file here.
};

export default class DeleteFiles extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="popup" border="primary">
        <div className="popup_inner">
          <Content>
            <h5>Are you sure you want to delete all of your files?</h5>
            <strong>This action can not be undone.</strong>
          </Content>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="button" variant="secondary" onClick={this.props.closePopup}>Close</button>
            <button type="button" className="btn-outline-primary" color="primary" onClick={deleteFile} value={this.props.text}>Yes</button>
            <button type="button" className="btn-outline-primary" color="primary" onClick={this.props.closePopup}>No</button>
          </div>
        </div>
      </div>
    );
  }
}
