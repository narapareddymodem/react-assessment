import React from 'react';
import { render, screen } from '@testing-library/react';
import UserList from '../UserList.jsx';
import 'jest-styled-components';


const users = [
  {
    id: 1,
    name: 'Leanne Graham',
    username: 'Bret',
    email: 'Sincere@april.biz',
    address: {
      street: 'Kulas Light',
      suite: 'Apt. 556',
      city: 'Gwenborough',
      zipcode: '92998-3874',
      geo: {
        lat: '-37.3159',
        lng: '81.1496'
      }
    }
  }
];

global.fetch = jest.fn(() => Promise.resolve({
  json: () => Promise.resolve(users)
}));

it('renders correctly', () => {
  const { container } = render(<UserList />);
  expect(container).toMatchSnapshot();
});

describe('UserList', () => {
  it('Should have proper username after data fetch', async () => {
    // need to put mock logic here to make it work

    render(<UserList />);
    // const username = await screen.username()
    // expect(username.textContent).toBe("Bret");
  });
});
