import React from 'react';
import { render } from '@testing-library/react';
import TaskOne from '../TaskOne.jsx';
import 'jest-styled-components';

global.fetch = jest.fn(() => Promise.resolve({
  json: () => Promise.resolve({
    value: 'Testing something!'
  })
}));

it('renders correctly', () => {
  const { container } = render(<TaskOne />);
  expect(container).toMatchSnapshot();
});
