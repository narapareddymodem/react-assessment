/* eslint-disable */
import React, { Component } from 'react';
import { Row, UserInfo, Users } from './Styles';

const debounce = (func, wait) => {
  let timeout = null;

  const cleanup = () => {
    if (timeout) clearTimeout(timeout);
  };

  return () => {
    cleanup();

    timeout = setTimeout(func, wait);
  };
};

export default class UserList extends Component {
  constructor(props) {
    super(props);
    this.fetchData = debounce(this.fetchData.bind(this));

    this.state = {
      data: [],
      filter: '',
      value: ''
    };
  }

  componentDidMount() {
    this.fetchData();
  }

  fetchData = () => {
    const { filter } = this.state;
    fetch(`https://jsonplaceholder.typicode.com/users${filter ? `?username=${encodeURIComponent(filter)}` : ''}`).then(async (response) => {
      const data = await response.json();
      this.setState({ data });
      console.log('Web service request fired: '+data);
    });
  }

  debounceFn = debounce((e) => {
    this.setState({ filter: this.state.value }, this.fetchData);
  }, 5000);

  render() {
    const { data, value } = this.state;

    const setFilter = (e) => {
      this.setState({ value: e.target.value });
      // console.log(`--->>${e.target.value}`);
      this.debounceFn(this.state);
    };

    return (
      <div>
        <div>
          Filter:
          <input
            type="text"
            onChange={setFilter}
            value={this.state.value}
            placeholder="Enter username"
          />
        </div>
        <Users>
          {data.map((user) => (
            <Row key={user.id}>
              <UserInfo>
                <span>{`Name: ${user.name}`}</span>
                <span>{`Username: ${user.username}`}</span>
              </UserInfo>
              <div>
                <div>
                  <span>{user.address.street}</span>
                  <span>{user.address.suite}</span>
                  <span>{user.address.city}</span>
                  <span>{user.address.zipcode}</span>
                </div>
                <div>
                  <span>{user.email}</span>
                  <span>{user.phone}</span>
                </div>
              </div>
            </Row>
          ))}
        </Users>
      </div>
    );
  }
}
