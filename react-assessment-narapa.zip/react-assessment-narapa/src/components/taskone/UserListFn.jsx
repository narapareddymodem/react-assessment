
import React, { useEffect, useState } from 'react';
import { Row, UserInfo, Users } from './Styles';

const debounce = (func, wait = 5000) => {
  let timeout = null;

  const cleanup = () => {
    if (timeout) clearTimeout(timeout);
  };

  return () => {
    cleanup();

    timeout = setTimeout(func, wait);
  };
};

export default function UserListFn() {
  const [data, setData] = useState([]);
  const [value, setValue] = useState('');

  const fetchData = (filter) => {
    fetch(`https://jsonplaceholder.typicode.com/users${filter ? `?username=${encodeURIComponent(filter)}` : ''}`).then(async (response) => {
      const responseData = await response.json();
      console.log(`Data retrieved: ${responseData}`);
      setData(responseData);
    }, []);
  };

  useEffect(() => {
    fetchData(value);
  }, []);

  const handleChange = (event) => {
    setValue(event.target.value);
    debounce(fetchData(event.target.value));
  };

  return (
    <div>
      <div>
        Filter:
        <input
          type="text"
          onChange={handleChange}
          value={value}
          placeholder="Enter username"
        />
      </div>
      <Users>
        {data.map((user) => (
          <Row key={user.id}>
            <UserInfo>
              <span>{`Name: ${user.name}`}</span>
              <span>{`Username: ${user.username}`}</span>
            </UserInfo>
            <div>
              <div>
                <span>{user.address.street}</span>
                <span>{user.address.suite}</span>
                <span>{user.address.city}</span>
                <span>{user.address.zipcode}</span>
              </div>
              <div>
                <span>{user.email}</span>
                <span>{user.phone}</span>
              </div>
            </div>
          </Row>
        ))}
      </Users>
    </div>
  );
}
